package com.cg.asset.controllers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.cg.asset.dtos.*;
import com.cg.asset.exception.*;
import com.cg.asset.dtos.Asset;
import com.cg.asset.dtos.Request;
import com.cg.asset.dtos.User;
import com.cg.asset.exception.AssetException;
import com.cg.asset.services.*;

@Controller
@Scope("session")
public class AssetController {

	private IAssetServices services;

	@Resource(name="assetService")
	public void setAssetServices(IAssetServices services){
		this.services = services;
	}
	

	@RequestMapping("login.do")
	public ModelAndView getEmpAddFormPage(){
		ModelAndView model = new ModelAndView("login");
		return model;
	}
		
	@RequestMapping("authenticate.do")
	public ModelAndView submitEmpAddForm(HttpSession session ,@RequestParam("userName")String userName,
		@RequestParam("password") String password){
		ModelAndView model =new ModelAndView();       //@ModelAttribute is used as object comes from form. 

		
			System.out.println("username  = "+userName);
			System.out.println("password  = "+password);
			
			try {
				int userType = services.authenticate(userName, password);
				System.out.println("usertype = "+userType);
				
				if (userType == 1)
				{	
					System.out.println("Admin authenticated successfully");
					session.setAttribute("userName", userName);
					model.setViewName("adminHomePage");		
					model.addObject("userName",userName);
				}
				else if(userType == 2)
				{	
					System.out.println("Manager authenticated successfully");
					session.setAttribute("userName", userName);
					int mgrId = services.getEmployeeNoFromUserName(userName);
					System.out.println(" EmployeeId of manager is = "+mgrId);
					session.setAttribute("mgrId", mgrId);
					session.setAttribute("userName", userName);
					model.setViewName("managerHomePage");	
					
				}else{
					model.setViewName("login");
					model.addObject("errorMsg","Incorrect UserName OR Password");
				}
			} catch (AssetException e) {
				System.out.println("Login Failed. Incorrect UserName");
				model.setViewName("login");
				model.addObject("errorMsg","Login Failed. Incorrect UserName");
			}
			return model;

	}
	
	@RequestMapping("createAssetRequestData.do")
	public ModelAndView createAssetRequestData(HttpSession session, HttpServletRequest request){
		ModelAndView model =null;
		List<String> empNames = new ArrayList<>();
		
		session = request.getSession(false);
		int mgrId = (int) session.getAttribute("mgrId");
		
		try {
			empNames = services.getAvailableEmployees(mgrId);
			List<Asset> availAssetsDetail= services.getAvailableAssetsDetails();
			
			//session.setAttribute("availableEmps", empNames);
			//session.setAttribute("availAssetsDetail", availAssetsDetail);
			
			model.addObject("availableEmps", empNames);
			model.addObject("availAssetsDetail", availAssetsDetail );
			model.addObject("request", new Request()); 
			model= new ModelAndView("requestForm");
		} catch (AssetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return model;
		
	}
	
	@RequestMapping("addRequest.do")
	public ModelAndView submitAssetRequest(HttpSession session ,
									HttpServletRequest request,
									@ModelAttribute("request")Request req, BindingResult result 
			){		
		ModelAndView model =null;
		String message;
		
		/*session = request.getSession(false);
		int mgrId = (int) session.getAttribute("mgrId");
		
		int empId = services.getEmpNo(empName);
		int assetId = services.getAssetId(assetName);
		//String reqStrDate = request.getParameter("reqDate").toString();
		java.util.Date date = new SimpleDateFormat("yyyy-MM-dd")
				.parse(reqStrDate); //
		java.sql.Date reqSQLDate = new java.sql.Date(date.getTime());*/
		System.out.println(req);
		
		

	
		return model;
	}
	
	@RequestMapping("showAssets.do")
	public ModelAndView getshowAssetsPage(){
		
		ModelAndView model = new ModelAndView("showAssets");
		try {
			
			List<Asset> assetList = services.getAssetDetailsListAdmin();
			model.addObject("asset", assetList);
		
		} catch (AssetException e) {
			e.printStackTrace();
		}
	
		return model;
	}
	
	@RequestMapping("logout.do")
	public ModelAndView logout(){
		
		ModelAndView model = new ModelAndView("login");	
		return model;
	}
	
	
	
	
	
}
