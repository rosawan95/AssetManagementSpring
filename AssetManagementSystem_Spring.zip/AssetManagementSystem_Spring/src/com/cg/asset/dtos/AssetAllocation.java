package com.cg.asset.dtos;

import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity(name="Asset_Allocation")
@Table(name="Asset_Allocation")

@SequenceGenerator( name="allocation_id_seq", sequenceName="asset_allocation_id_seq", allocationSize=1 , initialValue=1)
public class AssetAllocation {

	private int allocationId;
	private int assetId;
	private int empNo;
	private Date allocationDate;
	private Date releaseDate;

	@Override
	public String toString() {
		return "AssetAllocation [allocationId=" + allocationId + ", assetId="
				+ assetId + ", empNo=" + empNo + ", allocationDate="
				+ allocationDate + ", releaseDate=" + releaseDate + "]";
	}

	@Id
	@Column(name="allocationid")
	@GeneratedValue(generator = "allocation_id_seq", strategy=GenerationType.SEQUENCE)
	public int getAllocationId() {
		return allocationId;
	}

	public void setAllocationId(int allocationId) {
		this.allocationId = allocationId;
	}

	@Column(name="assetid")
	public int getAssetId() {
		return assetId;
	}

	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}
	
	@Column(name="empno")
	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}



	@Column(name="allocation_date")
	public Date getAllocationDate() {
		return allocationDate;
	}

	public void setAllocationDate(Date allocationDate) {
		this.allocationDate = allocationDate;
	}

	@Column(name="release_date")
	public Date getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}
	
	/*
	public AssetAllocation() {
		super();
	}

	public AssetAllocation(int allocationId, int assetId, int empNo,
			Date allocationDate, Date releaseDate) {
		super();
		this.allocationId = allocationId;
		this.assetId = assetId;
		this.empNo = empNo;
		this.allocationDate = allocationDate;
		this.releaseDate = releaseDate;
	}*/

}
