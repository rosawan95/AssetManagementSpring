package com.cg.asset.dtos;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity(name="ASSET")
@Table(name="asset")
@NamedQueries({
	@NamedQuery(name = "qryAllAssets" , query = "select a from ASSET a"),
	@NamedQuery(name = "qryAvailableAssetsDetails" , query = "SELECT assetname, assetdes FROM ASSET a WHERE quantity is >0"),
	@NamedQuery(name = "qryAssetIdFromAssetName" , query = "SELECT assetname, assetdes FROM ASSET WHERE quantity is :quantity")
})

@SequenceGenerator( name="asset_id_seq", sequenceName="asset_id_seq", allocationSize=1 , initialValue=1010)
public class Asset {

	List<Request> req;
	
	@OneToMany(mappedBy="asset")
	public List<Request> getReq() {
		return req;
	}

	public void setReq(List<Request> req) {
		this.req = req;
	}

	private int assetId;
	private String assetName;
	private String assetDesc;
	private int quantity;
	private String status;

	@Override
	public String toString() {
		return "Asset [assetId=" + assetId + ", assetName=" + assetName
				+ ", assetDesc=" + assetDesc + ", quantity=" + quantity
				+ ", status=" + status + "]";
	}

	@Id
	@Column(name="assetid")
	@GeneratedValue(generator = "asset_id_seq", strategy=GenerationType.SEQUENCE)
	public int getAssetId() {
		return assetId;
	}

	
	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}

	
	@Column(name="assetname")
	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	
	@Column(name="assetdes")
	public String getAssetDesc() {
		return assetDesc;
	}

	public void setAssetDesc(String assetDesc) {
		this.assetDesc = assetDesc;
	}

	@Column(name="quantity")
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Column(name="status")
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


}
