package com.cg.asset.services;

import java.sql.Date;
import java.util.Calendar;
import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;









import com.cg.asset.daos.AssetDaoImpl;
import com.cg.asset.dtos.Asset;
import com.cg.asset.dtos.User;
import com.cg.asset.dtos.UserMapEmployee;
import com.cg.asset.exception.AssetException;

@Service("assetService")
@Transactional
public class AssetServicesImpl implements IAssetServices {

	
	AssetDaoImpl dao;

	
	@Resource(name="assetDao")
	public void setAssetDao(AssetDaoImpl dao){
		this.dao = dao;
	}


	@Override
	public List<Asset> getAssetDetailsListAdmin() throws AssetException {
		return dao.getAssetDetailsListAdmin();
	}


	@Override
	public int authenticate(String userName, String password)
			throws AssetException {
		
		User user = dao.getUserDetails(userName);
		String privilege = "Admin";

		System.out.println(user);

		if (password.equals(user.getUserPassword())) {
			if (privilege.equals(user.getUserType())) {
				return 1;
			}
			return 2;
		}

		return 0;
	}
	@Override
	public boolean isDateValid(Date reqSQLDate) {
		java.sql.Date todaysDate = new java.sql.Date(Calendar.getInstance()
				.getTime().getTime());

		System.out.println("Todays date: " + todaysDate);
		System.out.println("User entered date: " + reqSQLDate);

		if (reqSQLDate.compareTo(todaysDate) > 0) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public int getEmployeeNoFromUserName(String userName) throws AssetException {
		UserMapEmployee umpe = dao.getEmployeeNoFromUserName(userName);
		return umpe.getEmpId();
	}


	@Override
	public List<String> getAvailableEmployees(int mgrId) throws AssetException {
		// TODO Auto-generated method stub
		return dao.getAvailableEmployees(mgrId);
	}


	@Override
	public List<Asset> getAvailableAssetsDetails() throws AssetException {
		// TODO Auto-generated method stub
		return dao.getAvailableAssetsDetails();
	}


	@Override
	public int getEmpNo(String empName) throws AssetException {
		// TODO Auto-generated method stub
		return dao.getEmpNo(empName);
	}

	@Override
	public int getAssetId(String assetName) throws AssetException {
		// TODO Auto-generated method stub
		return dao.getAssetId(assetName);
	}	
}