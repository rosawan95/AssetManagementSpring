package com.cg.asset.services;

import java.sql.Date;
import java.util.List;

import com.cg.asset.dtos.*;
import com.cg.asset.exception.*;


public interface IAssetServices {
	
	public List<Asset> getAssetDetailsListAdmin() throws AssetException;
	
	public int authenticate(String userName, String password) throws AssetException;
	
	public int getEmployeeNoFromUserName(String userName) throws AssetException;
	
	//To create data which is to be displayed on the asset request form
	List<String> getAvailableEmployees(int mgrId) throws AssetException;
	List<Asset> getAvailableAssetsDetails() throws AssetException;
		
	//Add asset request data. 
	int getEmpNo(String empName) throws AssetException;
	int getAssetId(String assetName) throws AssetException;

	boolean isDateValid(Date reqSQLDate);
	
	
}
