package com.cg.asset.daos;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import com.cg.asset.dtos.*;
import com.cg.asset.exception.*;

@Repository("assetDao")
public class AssetDaoImpl implements IAssetDao {
	
	@PersistenceContext
	private EntityManager manager;
	
	
	@Override
	public List<Asset> getAssetDetailsListAdmin() throws AssetException {
		Query query = manager.createNamedQuery("qryAllAssets",Asset.class);
		return query.getResultList();
	}

	
	@Override
	public User getUserDetails(String userName) throws AssetException {

		System.out.println(userName);
		Query query = manager.createNamedQuery ("qryUserOnUsername",User.class);
		query.setParameter("uname",userName);
		return (User) query.getSingleResult();
		
	}


}
