package com.cg.asset.daos;

import java.util.List;

import com.cg.asset.dtos.*;
import com.cg.asset.exception.*;

public interface IAssetDao {

	public List<Asset> getAssetDetailsListAdmin() throws AssetException;

	public User getUserDetails(String userName) throws AssetException;

	
	
}
