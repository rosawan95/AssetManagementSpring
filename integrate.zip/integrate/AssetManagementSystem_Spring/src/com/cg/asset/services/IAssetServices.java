package com.cg.asset.services;

import java.util.List;

import com.cg.asset.dtos.*;
import com.cg.asset.exception.*;


public interface IAssetServices {
	
	public List<Asset> getAssetDetailsListAdmin() throws AssetException;
	
	public List<Integer> authenticate(String userName, String password) throws AssetException;
	
	//public int getEmployeeNoFromUserName(String userName) throws AssetException;
	
	
	
}
