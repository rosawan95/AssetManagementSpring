package com.cg.asset.controllers;

import java.util.List;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.asset.dtos.*;
import com.cg.asset.exception.*;
import com.cg.asset.dtos.Asset;
import com.cg.asset.dtos.User;
import com.cg.asset.exception.AssetException;
import com.cg.asset.services.*;

@Controller
public class AssetController {

	private IAssetServices services;

	@Resource(name="assetService")
	public void setAssetServices(IAssetServices services){
		this.services = services;
	}
	

	@RequestMapping("login.do")
	public ModelAndView getEmpAddFormPage(){
		ModelAndView model = new ModelAndView("login");
		return model;
	}
	
	
	@RequestMapping("authenticate.do")
	public ModelAndView submitEmpAddForm(@RequestParam("userName") String uname,@RequestParam("password") String password){
		ModelAndView model =new ModelAndView();       //@ModelAttribute is used as object comes from form. 

		
			System.out.println("username  = "+uname);
			System.out.println("password  = "+password);
			
			try {
				int userType = services.authenticate(uname, password);
				System.out.println("usertype = "+userType);
				
				if (userType == 1)
				{	
					System.out.println("Admin authenticated successfully");
					model.setViewName("adminHomePage");		
					model.addObject("userName",uname);
				}
				else if(userType == 2)
				{	
					System.out.println("Manager authenticated successfully");
					int empId = services.getEmployeeNoFromUserName(uname);
					System.out.println(" EmployeeId of manager is = "+empId);
					model.setViewName("managerHomePage");
					model.addObject("empId",empId);
					model.addObject("userName",uname);
					
				}else{
					model.setViewName("login");
					model.addObject("errorMsg","Incorrect UserName OR Password");
				}
			} catch (AssetException e) {
				System.out.println("Login Failed. Incorrect UserName");
				model.setViewName("login");
				model.addObject("errorMsg","Login Failed. Incorrect UserName");
			}
			return model;

	}
	
	
	
	@RequestMapping("showAssets.do")
	public ModelAndView getshowAssetsPage(){
		
		ModelAndView model = new ModelAndView("showAssets");
		try {
			
			List<Asset> assetList = services.getAssetDetailsListAdmin();
			model.addObject("asset", assetList);
		
		} catch (AssetException e) {
			e.printStackTrace();
		}
	
		return model;
	}
	
	
	@RequestMapping("logout.do")
	public ModelAndView logout(){
		
		ModelAndView model = new ModelAndView("login");	
		return model;
	}
	
	@RequestMapping("rejectRequest.do")
	public ModelAndView rejectRequest(@RequestParam("requestId") int requestId){
		ModelAndView model = null;
		System.out.println("Request Id  = "+requestId);
		
		try {
			Request req = services.rejectRequest(requestId);
			System.out.println(req);
			if(req!=null){
				System.out.println("Rejected Successfully");
				model = new ModelAndView("showPendingRequests.do");
				
			}else
			{
				System.out.println("Failed to reject request");
			}
			
		} catch (AssetException e) {
			
			e.printStackTrace();
		}
		
		
		return model;
	
		
	}
/*	else if (path.equals("/rejectRequest.do")) {
		try {
			String data = request.getQueryString();
			System.out.println(data + "  before");
			String data1 = data.substring(3, data.length());
			int requestId = Integer.parseInt(data1);
			System.out.println("after substring " + requestId);
			boolean boo = service.rejectRequest(requestId);
			if (boo == true) {
				// System.out.println("Request reject successfully");
				mylogger.info("Request reject successfully");
			} else {
				// System.out.println("Failed to deny request ");
				mylogger.error("Failed to deny request");
			}
			nextJsp = "/showPendingRequests.do";
		} catch (NumberFormatException e) {
			nextJsp = "error1.jsp";
			request.setAttribute("errorMsg", e);
			mylogger.error("Failed to deny request because of NumberFormatException");
		} catch (AssetException e) {
			nextJsp = "error1.jsp";
			request.setAttribute("errorMsg", e);
			mylogger.error("Failed to deny request");
		}
	}*/
	
	
	
}
