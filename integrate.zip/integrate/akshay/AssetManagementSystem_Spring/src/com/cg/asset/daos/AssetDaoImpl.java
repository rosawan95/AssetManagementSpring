package com.cg.asset.daos;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.asset.dtos.*;
import com.cg.asset.dtos.*;
import com.cg.asset.exception.*;

@Repository("assetDao")

public class AssetDaoImpl implements IAssetDao {
	
	@PersistenceContext
	private EntityManager manager;
	private EntityManagerFactory factory;
	
	
	@Override
	public List<Asset> getAssetDetailsListAdmin() throws AssetException {
		Query query = manager.createNamedQuery("qryAllAssets",Asset.class);
		return query.getResultList();
	}


	@Override
	public User getUserDetails(String userName) throws AssetException {
		
		Query query = manager.createNamedQuery("qryUserOnUsername",User.class);
		query.setParameter("uname",userName);
		
		return (User) query.getSingleResult();
		
	}


	@Override
	public UserMapEmployee getEmployeeNoFromUserName(String userName) throws AssetException {
		
		Query query = manager.createNamedQuery("qryEmpIdFromUsername",UserMapEmployee.class);
		query.setParameter("uname",userName);	
		return (UserMapEmployee) query.getSingleResult();
	
	}


	@Override
	public Request rejectRequest(int requestId) throws AssetException {
	//	String qryStr = "update  request set status :stat where requestid :id";
		EntityManager manager = factory.createEntityManager();
		//Query query = manager.createQuery(qryStr, Request.class);
		Request req= getRequestDetails(requestId);
		req.setStatus("Denied");
		/*manager.merge(req);*/
		
		//query.setParameter("stat", "Denied");
		//query.setParameter("id", requestId);
		
		return manager.merge(req);
	}

	public Request getRequestDetails(int requestId) throws AssetException  {
		
		EntityManager manager = factory.createEntityManager();
		Request request = manager.find(Request.class, requestId);
		return request;
		
	}



}
