package com.cg.asset.dtos;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity(name="REQUEST")
@Table(name="REQUEST")
public class Request {

	private int requestId;
	private int mgrId;
	private int empNo;
	private int assetId;
	private Date requestDate;
	private int requestForDays;
	private String status;

	@Override
	public String toString() {
		return "Request [requestId=" + requestId + ", mgrId=" + mgrId
				+ ", empNo=" + empNo + ", assetId=" + assetId
				+ ", requestDate=" + requestDate + ", requestForDays="
				+ requestForDays + ", status=" + status + "]";
	}
	
	
	@Id
	@Column(name="requestid")
	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	@Column(name="mgrId")
	public int getMgrId() {
		return mgrId;
	}

	public void setMgrId(int mgrId) {
		this.mgrId = mgrId;
	}

	@Column(name="empno")
	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	@Column(name="assetid")
	public int getAssetId() {
		return assetId;
	}

	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}

	@Column(name="requestdate")
	public Date getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(Date requestDate) {
		this.requestDate = requestDate;
	}

	@Column(name="requestfordays")
	public int getRequestForDays() {
		return requestForDays;
	}

	public void setRequestForDays(int requestForDays) {
		this.requestForDays = requestForDays;
	}

	@Column(name="status")
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
