package com.cg.asset.controllers;

import java.util.List;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;



import com.cg.asset.dtos.*;
import com.cg.asset.exception.*;
import com.cg.asset.dtos.Asset;
import com.cg.asset.dtos.Request;

import com.cg.asset.dtos.User;
import com.cg.asset.exception.AssetException;
import com.cg.asset.services.*;

@Controller
public class AssetController {

	private IAssetServices services;

	@Resource(name="assetService")
	public void setAssetServices(IAssetServices services){
		this.services = services;
	}
	

	@RequestMapping("login.do")
	public ModelAndView getEmpAddFormPage(){
		ModelAndView model = new ModelAndView("login");
		return model;
	}
	
	
	@RequestMapping("authenticate.do")
	public ModelAndView submitEmpAddForm(@RequestParam("userName") String uname,@RequestParam("password") String password){
		ModelAndView model =new ModelAndView();       //@ModelAttribute is used as object comes from form. 

		
			System.out.println("username  = "+uname);
			System.out.println("password  = "+password);
			
			try {
				int userType = services.authenticate(uname, password);
				System.out.println("usertype = "+userType);
				
				if (userType == 1)
				{	
					System.out.println("Admin authenticated successfully");
					model.setViewName("adminHomePage");		
					model.addObject("userName",uname);
				}
				else if(userType == 2)
				{	
					System.out.println("Manager authenticated successfully");
					int empId = services.getEmployeeNoFromUserName(uname);
					System.out.println(" EmployeeId of manager is = "+empId);
					model.setViewName("managerHomePage");
					model.addObject("empId",empId);
					model.addObject("userName",uname);
					
				}else{
					model.setViewName("login");
					model.addObject("errorMsg","Incorrect UserName OR Password");
				}
			} catch (AssetException e) {
				System.out.println("Login Failed. Incorrect UserName");
				model.setViewName("login");
				model.addObject("errorMsg","Login Failed. Incorrect UserName");
			}
			return model;

	}
	
	
	
	@RequestMapping("showAssets.do")
	public ModelAndView getshowAssetsPage(){
		
		ModelAndView model = new ModelAndView("showAssets");
		try {
			
			List<Asset> assetList = services.getAssetDetailsListAdmin();
			model.addObject("asset", assetList);
		
		} catch (AssetException e) {
			e.printStackTrace();
		}
	
		return model;
	}
	
	@RequestMapping("showPendingRequests.do") 
	public ModelAndView showPendingRequests(){
		
		ModelAndView model = new ModelAndView("pendingRequestList");
		try {
			List<Request> pendingRequestList = services.getRequestsPendingList();
			System.out.println("here");
			System.out.println(pendingRequestList);
			model.addObject("requests", pendingRequestList);
			
		} catch (AssetException e) {
			e.printStackTrace();
		
		}
		return model;
	}

	
	@RequestMapping("addNewAsset.do")
	public ModelAndView addAsset() {

		ModelAndView model = new ModelAndView("addAssetForm");
		model.addObject("asset",new Asset());
		return model;

	}

	@RequestMapping("submitAssets.do")
	public ModelAndView ast(@ModelAttribute("asset") @Valid Asset asset1,
			BindingResult result) throws AssetException {
		
		ModelAndView model = new ModelAndView();
		if(result.hasErrors()) {
		model.setViewName("addAssetForm");
		
		return model;
	}
		System.out.println(asset1);
		Asset ast=services.addNewAsset(asset1);
		System.out.println(ast);
		model.setViewName("showAssets");
		try {
			
			List<Asset> assetList = services.getAssetDetailsListAdmin();
			model.addObject("asset", assetList);
		
		} catch (AssetException e) {
			e.printStackTrace();
		}
	
		return model;
	}
	
	
	@RequestMapping("/adminModify.do")
    public ModelAndView updateform(@RequestParam("id") int assetId){
		System.out.println("inside update.do");
		ModelAndView model=new ModelAndView();
		try {
			Asset asset = services.getAssetDetails(assetId);
			System.out.println(asset);
			
			model = new ModelAndView("modifyAssetForm");
			model.addObject("asset",asset);
		} catch (AssetException e) {
			model = new ModelAndView("error");
			model.addObject("errMsg","Record update failed" +e.getMessage());
		}
		return model;
	}	
	
	@RequestMapping("/adminUpdateConfirm.do")
	public String submitupdateform(@ModelAttribute("asset")  Asset asset,
	@RequestParam ("id")int assetId,@RequestParam("plusquantity")int plusQuantity,Model model) throws AssetException{	
		
		
		System.out.println(asset);
		int q=asset.getQuantity();
		int q1=q+plusQuantity;
		asset.setQuantity(q1);
        Asset assetResponse =services.updateAssetAdd(asset);
        System.out.println(assetResponse);
		
try {
			
			List<Asset> assetList = services.getAssetDetailsListAdmin();
			model.addAttribute("asset",assetList);
		
		
		} catch (AssetException e) {
			e.printStackTrace();
		}
	
        	
//	model.addObject("asset",assetResponse);
		/*Product productResponse = services.updateProduct(product);
		model.addAttribute("productdetails",productResponse);*/
		return "showAssets";
		
		
}
	
	
	@RequestMapping("logout.do")
	public ModelAndView logout(){
		
		ModelAndView model = new ModelAndView("login");	
		return model;
	}
	
	
	
	
	
}
