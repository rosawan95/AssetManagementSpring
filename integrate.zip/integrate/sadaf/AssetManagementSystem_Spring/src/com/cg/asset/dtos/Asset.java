package com.cg.asset.dtos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity(name="asset")
@Table(name="asset")
@NamedQueries({

	@NamedQuery(name = "qryAllAssets" , query = "select a from asset a"),
	@NamedQuery(name = "qryassetid" , query = "select a from asset a where assetId is :assetno"),
	//@NamedQuery(name = "qry" , query = "update asset set quantity = quantity + (quantity=:q1) where assetId = :assetno")
	//@NamedQuery(name = "qryEmpsComm" , query = "select e from employee e where commission IS NOT NULL"),
})

@SequenceGenerator( name="asset_id_seq", sequenceName="asset_id_seq", allocationSize=1 , initialValue=1010)
public class Asset {

  	private int assetId;
	private String assetName;
	private String assetDesc;
	private int quantity;
	private String status;

	@Override
	public String toString() {
		return "Asset [assetId=" + assetId + ", assetName=" + assetName
				+ ", assetDesc=" + assetDesc + ", quantity=" + quantity
				+ ", status=" + status + "]";
	}

	@Id
	@Column(name="assetid")
	@GeneratedValue(generator = "asset_id_seq", strategy=GenerationType.SEQUENCE)
	public int getAssetId() {
		return assetId;
	}

	
	public void setAssetId(int assetId) {
		this.assetId = assetId;
	}

	
	@Column(name="assetname")
	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	
	@Column(name="assetdes")
	public String getAssetDesc() {
		return assetDesc;
	}

	public void setAssetDesc(String assetDesc) {
		this.assetDesc = assetDesc;
	}

	@Column(name="quantity")
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Column(name="status")
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	/*public Asset() {
		super();
	}

	public Asset(int assetId, String assetName, String assetDesc, int quantity,
			String status) {
		super();
		this.assetId = assetId;
		this.assetName = assetName;
		this.assetDesc = assetDesc;
		this.quantity = quantity;
		this.status = status;
	}*/

}
