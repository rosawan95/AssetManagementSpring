package com.cg.asset.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.asset.dtos.*;
import com.cg.asset.exception.*;

@Repository("assetDao")
public class AssetDaoImpl implements IAssetDao {
	
	@PersistenceContext
	private EntityManager manager;
	
	
	@Override
	public List<Asset> getAssetDetailsListAdmin() throws AssetException {
		Query query = manager.createNamedQuery("qryAllAssets",Asset.class);
		return query.getResultList();
	}

	
	@Override
	public User getUserDetails(String userName) throws AssetException {

		System.out.println(userName);
		Query query = manager.createNamedQuery ("qryUserOnUsername",User.class);
		query.setParameter("uname",userName);
		return (User) query.getSingleResult();
		
	}

	@Override
	public Asset updateAssetAdd(Asset assets)throws AssetException {
		
		manager.merge(assets);
	
		return assets;
	}


	@Override
	public List<Request> getRequestsPendingList() throws AssetException {
		
		Query query = manager.createNamedQuery("qryRequeststatus",Request.class);
        query.setParameter("status", "Pending");
		return query.getResultList();
	}


	@Override
	public Asset getAssetDetails(int assetId) throws AssetException {
		Query query=manager.createNamedQuery("qryAssetOnId",Asset.class);
		query.setParameter("assetno", assetId);
		return (Asset) query.getSingleResult();
		
	}


	@Override
	public Asset addNewAsset(Asset asset) throws AssetException {
		manager.persist(asset);
		return asset;
	}

	

	@Override
	public Request rejectRequest(int requestId) throws AssetException {
	
		Request req= getRequestDetails(requestId);
		req.setStatus("Denied");
		return manager.merge(req);
	
	}

	public Request getRequestDetails(int requestId) throws AssetException  {
		
		Request request = manager.find(Request.class, requestId);
		return request;
		
	}
	
	
	@Override
	public Request approveRequest(int requestId) throws AssetException {
		Request request= getRequestDetails(requestId);
		
		
		return null;
	}
	
	public AssetAllocation insertIntoAssetAllocation(AssetAllocation assetAllo){
		return null;	
	}


	
	
}
