package com.cg.asset.services;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.asset.daos.AssetDaoImpl;
import com.cg.asset.dtos.Asset;
import com.cg.asset.dtos.Request;
import com.cg.asset.dtos.User;
import com.cg.asset.exception.AssetException;

@Service("assetService")
@Transactional
public class AssetServicesImpl implements IAssetServices {

	
	AssetDaoImpl dao;

	
	@Resource(name="assetDao")
	public void setAssetDao(AssetDaoImpl dao){
		this.dao = dao;
	}


	@Override
	public List<Asset> getAssetDetailsListAdmin() throws AssetException {
		return dao.getAssetDetailsListAdmin();
	}


	@Override
	public List<Integer> authenticate(String userName, String password)
			throws AssetException {
		
		List<Integer> myList = new ArrayList<Integer>();
		
		User user = dao.getUserDetails(userName);
		String privilege = "Admin";

		System.out.println(user);

		if (password.equals(user.getUserPassword())) {
			if (privilege.equals(user.getUserType())) {
				
				myList.add(1);
				myList.add(0);
			}else{
			myList.add(2);
			int empId=user.getEmpid().getEmpno();
			System.out.println("employee id of manager logged in "+empId);
			myList.add(empId);
			}
		}
		else{
			myList.add(0);
		}
		return myList;
	
	}

	@Override
	public Asset updateAssetAdd(Asset assets)throws AssetException {
		
		return dao.updateAssetAdd(assets);
	}


	@Override
	public List<Request> getRequestsPendingList() throws AssetException {
	
		return dao.getRequestsPendingList();
	}


	@Override
	public Asset getAssetDetails(int assetId) throws AssetException {
		
		return dao.getAssetDetails(assetId);
	}


	@Override
	public Asset addNewAsset(Asset asset) throws AssetException {
		return dao.addNewAsset(asset);
	}
	
	@Override
	public Request rejectRequest(int requestId) throws AssetException {
		
		return dao.rejectRequest(requestId);
	}
	
}