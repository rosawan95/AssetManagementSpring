package com.cg.asset.dtos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity(name="userMapEmp")
@Table(name="user_map_employee")
@NamedQuery(name = "qryEmpIdFromUsername" , query = "select u from userMapEmp u where userName is :uname ")
public class UserMapEmployee {

	private String userName;
	private int empId;
	
	
	@Column(name="username")
	public String getUserName() {
		return userName;
	}
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	@Id
	@Column(name="empno")
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	
	
	@Override
	public String toString() {
		return "UserMapEmployee [userName=" + userName + ", empId=" + empId
				+ "]";
	}
	
	
}
