package com.cg.asset.services;

import java.util.List;

import com.cg.asset.dtos.*;
import com.cg.asset.exception.*;


public interface IAssetServices {
	
	public List<Asset> getAssetDetailsListAdmin() throws AssetException;
	
	public int authenticate(String userName, String password) throws AssetException;
	
	public int getEmployeeNoFromUserName(String userName) throws AssetException;
	
	public List<Request> getRequestsPendingList() throws AssetException;
	public Asset updateAssetAdd(Asset assets)throws AssetException;
	public Asset getAssetDetails(int assetId) throws AssetException;
	 public Asset addNewAsset(Asset asset) throws AssetException;
	//public Asset updateAsset(Asset asset)throws AssetException;
	 public boolean removeAsset(Asset asset) throws AssetException;
	 public List<Request> showAllRequests(int mgrId) throws AssetException;
	 public List<Integer> getAssetListAllocated() throws AssetException;
	
}
