package com.cg.asset.services;

import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;



import com.cg.asset.daos.AssetDaoImpl;
import com.cg.asset.dtos.Asset;
import com.cg.asset.dtos.Request;
import com.cg.asset.dtos.User;
import com.cg.asset.dtos.UserMapEmployee;
import com.cg.asset.exception.AssetException;

@Service("assetService")
@Transactional
public class AssetServicesImpl implements IAssetServices {

	
	AssetDaoImpl dao;

	
	@Resource(name="assetDao")
	public void setAssetDao(AssetDaoImpl dao){
		this.dao = dao;
	}


	@Override
	public List<Asset> getAssetDetailsListAdmin() throws AssetException {
		return dao.getAssetDetailsListAdmin();
	}


	@Override
	public int authenticate(String userName, String password)
			throws AssetException {
		
		User user = dao.getUserDetails(userName);
		String privilege = "Admin";

		System.out.println(user);

		if (password.equals(user.getUserPassword())) {
			if (privilege.equals(user.getUserType())) {
				return 1;
			}
			return 2;
		}

		return 0;
	}


	@Override
	public int getEmployeeNoFromUserName(String userName) throws AssetException {
		UserMapEmployee umpe = dao.getEmployeeNoFromUserName(userName);
		return umpe.getEmpId();
	}


	@Override
	public Asset updateAssetAdd(Asset assets)throws AssetException {
		
		return dao.updateAssetAdd(assets);
	}


	@Override
	public List<Request> getRequestsPendingList() throws AssetException {
	
		return dao.getRequestsPendingList();
	}


	@Override
	public Asset getAssetDetails(int assetId) throws AssetException {
		
		return dao.getAssetDetails(assetId);
	}


	@Override
	public Asset addNewAsset(Asset asset) throws AssetException {
		// TODO Auto-generated method stub
		return dao.addNewAsset(asset);
	}


	@Override
	public boolean removeAsset(Asset asset) throws AssetException {
		
		return dao.removeAsset(asset);
	}


	@Override
	public List<Request> showAllRequests(int mgrId) throws AssetException {
		
		return dao.showAllRequests(mgrId);
	}


	@Override
	public List<Integer> getAssetListAllocated() throws AssetException {
		
		return dao.getAssetListAllocated();
	}


	/*@Override
	public boolean updateAsset(int assetId, int plusQuantity) {
		// TODO Auto-generated method stub
		return dao.updateAsset(assetId, plusQuantity);
	}*/


	

	
	

	
}