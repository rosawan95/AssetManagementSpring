package com.cg.asset.daos;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;









import com.cg.asset.dtos.*;
import com.cg.asset.dtos.*;
import com.cg.asset.exception.*;

@Repository("assetDao")

public class AssetDaoImpl implements IAssetDao {
	
	@PersistenceContext
	private EntityManager manager;
	
	
	@Override
	public List<Asset> getAssetDetailsListAdmin() throws AssetException {
		Query query = manager.createNamedQuery("qryAllAssets",Asset.class);
		return query.getResultList();
	}


	@Override
	public User getUserDetails(String userName) throws AssetException {
		
		Query query = manager.createNamedQuery("qryUserOnUsername",User.class);
		query.setParameter("uname",userName);
		
		return (User) query.getSingleResult();
		
	}


	@Override
	public UserMapEmployee getEmployeeNoFromUserName(String userName) throws AssetException {
		
		Query query = manager.createNamedQuery("qryEmpIdFromUsername",UserMapEmployee.class);
		query.setParameter("uname",userName);	
		return (UserMapEmployee) query.getSingleResult();
	
	}


	@Override
	public Asset updateAssetAdd(Asset assets)throws AssetException {
		
		manager.merge(assets);
	
		return assets;
	}


	@Override
	public List<Request> getRequestsPendingList() throws AssetException {
		
		Query query = manager.createNamedQuery("qryRequeststatus",Request.class);
        query.setParameter("status", "Pending");
		return query.getResultList();
	}


	@Override
	public Asset getAssetDetails(int assetId) throws AssetException {
		Query query=manager.createNamedQuery("qryassetid",Asset.class);
		query.setParameter("assetno", assetId);
		return (Asset) query.getSingleResult();
	}


	@Override
	public Asset addNewAsset(Asset asset) throws AssetException {
		manager.persist(asset);
		return asset;
	}


	@Override
	public boolean removeAsset(Asset asset) throws AssetException {
		
		Asset assetresponse=manager.find(Asset.class,asset.getAssetId());
		manager.remove(assetresponse);
		return true;
		
	}
	
	@Override
	public List<Request> showAllRequests(int mgrId) throws AssetException {
		Query qry=manager.createNamedQuery("showList",Request.class);	
		//qry.setParameter("m", mgrId);		
		return qry.getResultList();
	}
	
	@Override
	public List<Integer> getAssetListAllocated() throws AssetException {
		Query query = manager.createNamedQuery("assetListAllocated",AssetAllocation.class);
		return query.getResultList();
		}
		
  /* public boolean updateAsset(int assetId, int plusQuantity){
	  
	   
	   
	   TypedQuery<Asset> query=manager.createNamedQuery("qry",Asset.class);
	   query.setParameter("q1",plusQuantity );
	   query.setParameter("assetno",assetId);
	   Asset update=query.getSingleResult();
	   if(update!=null){
	return true ;
	   }else{
		   return false;
	   }*/
   }
	

	
	




