package com.cg.asset.daos;

import java.util.List;

import com.cg.asset.dtos.*;
import com.cg.asset.exception.*;

public interface IAssetDao {

	public List<Asset> getAssetDetailsListAdmin() throws AssetException;

	public User getUserDetails(String userName) throws AssetException;

	public UserMapEmployee getEmployeeNoFromUserName(String userName) throws AssetException;
	
	 public List<Request> getRequestsPendingList() throws AssetException;	
	 public Asset updateAssetAdd(Asset assets)throws AssetException;
	 public Asset getAssetDetails(int assetId) throws AssetException;
	 public Asset addNewAsset(Asset asset) throws AssetException;
	 boolean removeAsset(Asset asset) throws AssetException;
	 public List<Request> showAllRequests(int mgrId) throws AssetException;
	 public List<Integer> getAssetListAllocated() throws AssetException;
}
